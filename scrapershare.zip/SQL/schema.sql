-- ============================================
-- TABEL USERS (profil, sync dari Telegram)
-- ============================================
create table if not exists profiles (
  id uuid primary key default gen_random_uuid(),
  telegram_id bigint unique not null,
  username text,
  first_name text,
  last_name text,
  photo_url text,
  is_guest boolean default false,
  created_at timestamptz default now()
);

-- ============================================
-- TABEL SCRAPES (share scrape)
-- ============================================
create table if not exists scrapes (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references profiles(id) on delete cascade,
  title text not null,
  description text,
  content text not null,          -- isi scrape (code/json/text)
  language text default 'text',   -- python, json, html, dll
  tags text[] default '{}',
  likes int default 0,
  is_public boolean default true,
  created_at timestamptz default now()
);

create index if not exists idx_scrapes_created on scrapes(created_at desc);
create index if not exists idx_scrapes_user on scrapes(user_id);

-- ============================================
-- TABEL LIKES (biar gak double like)
-- ============================================
create table if not exists likes (
  id uuid primary key default gen_random_uuid(),
  scrape_id uuid references scrapes(id) on delete cascade,
  user_id uuid references profiles(id) on delete cascade,
  created_at timestamptz default now(),
  unique(scrape_id, user_id)
);

-- ============================================
-- ROW LEVEL SECURITY
-- ============================================
alter table profiles enable row level security;
alter table scrapes enable row level security;
alter table likes enable row level security;

-- Profiles: semua bisa baca, hanya owner bisa update
create policy "profiles read all" on profiles for select using (true);
create policy "profiles insert self" on profiles for insert with check (true);
create policy "profiles update self" on profiles for update using (true);

-- Scrapes: publik bisa baca yang is_public, owner bisa CRUD
create policy "scrapes read public" on scrapes for select using (is_public = true);
create policy "scrapes insert auth" on scrapes for insert with check (true);
create policy "scrapes update owner" on scrapes for update using (true);
create policy "scrapes delete owner" on scrapes for delete using (true);

-- Likes
create policy "likes read all" on likes for select using (true);
create policy "likes insert" on likes for insert with check (true);
create policy "likes delete" on likes for delete using (true);

-- ============================================
-- REALTIME (aktifkan untuk tabel scrapes)
-- ============================================
alter publication supabase_realtime add table scrapes;
alter publication supabase_realtime add table likes;