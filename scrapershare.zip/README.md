# ScraperShare (SS)

Aplikasi share scrape realtime dengan UI Neubrutalism.

## Setup

### 1. Buat project Supabase
- Buka https://supabase.com → New Project
- Copy `Project URL` dan `anon public key`

### 2. Jalankan SQL
- Buka SQL Editor di Supabase
- Paste isi `sql/schema.sql` → Run

### 3. Konfigurasi client
Edit `js/supabase-client.js`:
```js
const SUPABASE_URL = "https://xxxx.supabase.co";
const SUPABASE_ANON_KEY = "eyJhbGciOi...";